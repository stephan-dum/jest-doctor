import runJest from '../runJest';

it('detects interval leaks', async () => {
  const result = await runJest([`${__dirname}/interval-leak.fixture.ts`]);
  expect(result.testResults[0].message).toContain('open interval');
});
