import runJest from '../runJest';

it('should work with done function', async () => {
  const result = await runJest([`${__dirname}/done.fixture.ts`]);
  expect(result.success).toEqual(true);
});
