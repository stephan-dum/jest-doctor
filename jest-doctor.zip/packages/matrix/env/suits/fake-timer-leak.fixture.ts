it('leaks fake timeout', () => {
  jest.useFakeTimers();
  setTimeout(() => {}, 1000);
});
