it('leaks', () => {
  setTimeout(() => {}, 1000);
});

it('is clean', () => {});
