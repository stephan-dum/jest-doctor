import { createRequire } from 'node:module';
const { resolve } = createRequire(import.meta.url);

export default {
  testEnvironment: resolve('jest-doctor/env/node'),
  transform: {
    '^.+\\.ts$': '@swc/jest',
  },
  reporters: [],
};
