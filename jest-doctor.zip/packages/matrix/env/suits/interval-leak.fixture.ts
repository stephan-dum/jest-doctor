it('leaks interval', () => {
  setInterval(() => {}, 1000);
});
