import { createRequire } from 'node:module';

const { resolve } = createRequire(import.meta.url);

export default {
  testMatch: [`${import.meta.dirname}/suits/**/*.test.ts`],
  transform: {
    '^.+\\.ts$': resolve('@swc/jest'),
  },
};

/*
module.exports = {
  testMatch: [`${__dirname}/suits/** /*.test.ts`],
  transform: {
    '^.+\\.ts$': require.resolve('@swc/jest'),
  },
};*/
