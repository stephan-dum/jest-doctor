import runJest from '../runJest';

it('detects fake timer leaks', async () => {
  const result = await runJest([`${__dirname}/fake-timer-leak.fixture.ts`]);
  expect(result.testResults[0].message).toContain('fake timeout');
});
