it('logs to console', () => {
  console.log('oops');
});
