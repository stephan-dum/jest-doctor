it('should work with done function', (done) => {
  done();
});
