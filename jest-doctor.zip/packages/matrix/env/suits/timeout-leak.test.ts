import runJest from '../runJest';

it('detects real timer leaks', async () => {
  const result = await runJest([`${__dirname}/timeout-leak.fixture.ts`]);
  expect(result.testResults[0].message).toContain('open timeout');
});
