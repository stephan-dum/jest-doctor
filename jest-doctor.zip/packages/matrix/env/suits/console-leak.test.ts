import runJest from '../runJest';

it('detects console output', async () => {
  const result = await runJest([`${__dirname}/console-leak.fixture.ts`]);
  expect(result.testResults[0].message).toContain('console output');
});
