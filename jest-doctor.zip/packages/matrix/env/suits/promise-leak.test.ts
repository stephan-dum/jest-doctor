import runJest from '../runJest';

describe('promise-leak', () => {
  it('detects unresolved promises', async () => {
    const result = await runJest([`${__dirname}/promise-leak.fixture.ts`]);
    expect(result.success).toBe(false);
    expect(result.testResults[0].message).toContain('open promise');
  });
});
