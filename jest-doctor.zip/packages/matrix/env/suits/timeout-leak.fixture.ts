it('leaks timeout', () => {
  setTimeout(() => {}, 1000);
});
