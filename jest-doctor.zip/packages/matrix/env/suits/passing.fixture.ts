it('is passes', async () => {
  jest.useFakeTimers();
  const resolvedPromise = new Promise<void>((resolve) => {
    setTimeout(resolve, 100);
  });
  jest.runAllTimers();
  await resolvedPromise;

  const rejectedPromise = new Promise<void>((_, reject) => {
    setTimeout(reject, 100);
  });
  jest.runAllTimers();
  try {
    await rejectedPromise;
  } catch {
    // empty
  }

  const id = setTimeout(() => {}, 0);
  clearTimeout(id);
});
